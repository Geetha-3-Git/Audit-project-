package com.audithub;

import org.springframework.stereotype.Component;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** In-memory storage (no database). Refilled from the Excel file on every sync. */
@Component
public class FaqStore {
    private final Map<String, Dto.FaqDto> byKey = new LinkedHashMap<>();
    private final Map<String, Long> ids = new HashMap<>();
    private final Map<String, Integer> scores = new LinkedHashMap<>();
    private long nextId = 1;

    public synchronized int apply(List<ExcelParser.Entry> rows, Map<String, Integer> newScores) {
        Map<String, Dto.FaqDto> next = new LinkedHashMap<>();
        for (ExcelParser.Entry e : rows) {
            String key = (e.category() + "|" + e.question()).trim().toLowerCase();
            if (next.containsKey(key)) {
                continue;                                   // ignore duplicate rows
            }
            Long id = ids.get(key);
            if (id == null) {
                id = nextId++;
                ids.put(key, id);
            }
            Dto.FaqDto old = byKey.get(key);
            List<Dto.VersionDto> versions;
            if (old == null) {
                versions = List.of(new Dto.VersionDto("1.0", LocalDate.now(), e.owner(), "Imported from Excel"));
            } else if (changed(old, e)) {
                versions = new ArrayList<>();
                versions.add(new Dto.VersionDto(nextVersion(old), LocalDate.now(), e.owner(), "Updated from Excel"));
                versions.addAll(old.versions());
            } else {
                versions = old.versions();
            }
            next.put(key, new Dto.FaqDto(id, e.category(), e.question(), e.answer(), e.owner(), e.status(),
                    e.reference(), e.updated(), e.nextReview(), versions));
        }
        byKey.clear();
        byKey.putAll(next);
        if (!newScores.isEmpty()) {
            scores.clear();
            scores.putAll(newScores);
        }
        return next.size();
    }

    public synchronized List<Dto.FaqDto> list() {
        List<Dto.FaqDto> all = new ArrayList<>(byKey.values());
        all.sort(Comparator.comparing(Dto.FaqDto::id));
        return all;
    }

    public synchronized Optional<Dto.FaqDto> get(long id) {
        return byKey.values().stream().filter(f -> f.id() == id).findFirst();
    }

    public synchronized Map<String, Integer> scores() {
        return new LinkedHashMap<>(scores);
    }

    private static boolean changed(Dto.FaqDto o, ExcelParser.Entry e) {
        return !o.answer().equals(e.answer()) || !o.owner().equals(e.owner()) || !o.status().equals(e.status())
                || !o.reference().equals(e.reference()) || !o.updated().equals(e.updated())
                || !o.nextReview().equals(e.nextReview());
    }

    private static String nextVersion(Dto.FaqDto o) {
        try {
            String v = o.versions().get(0).v();
            return "1." + (Integer.parseInt(v.substring(v.indexOf('.') + 1)) + 1);
        } catch (Exception ex) {
            return "1.1";
        }
    }
}
