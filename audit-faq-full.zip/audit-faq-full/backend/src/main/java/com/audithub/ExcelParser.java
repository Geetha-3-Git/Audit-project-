package com.audithub;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import java.io.ByteArrayInputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Reads the "FAQs" sheet (and optional "Compliance" sheet) by column header names. */
final class ExcelParser {
    record Entry(String category, String question, String answer, String owner, String status,
                 String reference, LocalDate updated, LocalDate nextReview) {}

    record Result(List<Entry> rows, Map<String, Integer> scores) {}

    private static final Set<String> STATUSES = Set.of("Approved", "Under Review", "Draft");

    private ExcelParser() {}

    static Result parse(byte[] bytes) throws Exception {
        try (Workbook wb = WorkbookFactory.create(new ByteArrayInputStream(bytes))) {
            DataFormatter fmt = new DataFormatter();

            Sheet sheet = wb.getSheet("FAQs");
            if (sheet == null) {
                sheet = wb.getSheetAt(0);
            }
            Map<String, Integer> cols = headers(sheet, fmt);

            List<Entry> rows = new ArrayList<>();
            for (int i = sheet.getFirstRowNum() + 1; i <= sheet.getLastRowNum(); i++) {
                Row r = sheet.getRow(i);
                if (r == null) {
                    continue;
                }
                String question = text(r, cols, "question", fmt);
                if (question.isBlank()) {
                    continue;
                }
                LocalDate updated = date(r, cols, "last updated", fmt);
                if (updated == null) {
                    updated = LocalDate.now();
                }
                LocalDate next = date(r, cols, "next review", fmt);
                if (next == null) {
                    next = updated.plusMonths(12);
                }
                String rawStatus = text(r, cols, "status", fmt);
                String status = "Draft";
                for (String s : STATUSES) {
                    if (s.equalsIgnoreCase(rawStatus)) {
                        status = s;
                    }
                }
                rows.add(new Entry(text(r, cols, "category", fmt), question, text(r, cols, "answer", fmt),
                        text(r, cols, "owner", fmt), status, text(r, cols, "control reference", fmt), updated, next));
            }

            Map<String, Integer> scores = new LinkedHashMap<>();
            Sheet cs = wb.getSheet("Compliance");
            if (cs != null) {
                Map<String, Integer> c = headers(cs, fmt);
                for (int i = cs.getFirstRowNum() + 1; i <= cs.getLastRowNum(); i++) {
                    Row r = cs.getRow(i);
                    if (r == null) {
                        continue;
                    }
                    String fw = text(r, c, "framework", fmt);
                    String sc = text(r, c, "score", fmt).replace("%", "").trim();
                    if (fw.isBlank() || sc.isBlank()) {
                        continue;
                    }
                    try {
                        scores.put(fw, (int) Math.round(Double.parseDouble(sc)));
                    } catch (NumberFormatException ignored) {
                        // skip bad score cell
                    }
                }
            }
            return new Result(rows, scores);
        }
    }

    private static Map<String, Integer> headers(Sheet sheet, DataFormatter fmt) {
        Map<String, Integer> map = new HashMap<>();
        Row head = sheet.getRow(sheet.getFirstRowNum());
        if (head != null) {
            for (Cell c : head) {
                map.put(fmt.formatCellValue(c).trim().toLowerCase(), c.getColumnIndex());
            }
        }
        return map;
    }

    private static String text(Row r, Map<String, Integer> cols, String key, DataFormatter fmt) {
        Integer idx = cols.get(key);
        if (idx == null) {
            return "";
        }
        Cell c = r.getCell(idx);
        return c == null ? "" : fmt.formatCellValue(c).trim();
    }

    private static LocalDate date(Row r, Map<String, Integer> cols, String key, DataFormatter fmt) {
        Integer idx = cols.get(key);
        if (idx == null) {
            return null;
        }
        Cell c = r.getCell(idx);
        if (c == null) {
            return null;
        }
        try {
            if (c.getCellType() == CellType.NUMERIC && DateUtil.isCellDateFormatted(c)) {
                return c.getLocalDateTimeCellValue().toLocalDate();
            }
            String s = fmt.formatCellValue(c).trim();
            return s.length() >= 10 ? LocalDate.parse(s.substring(0, 10)) : null;
        } catch (Exception e) {
            return null;
        }
    }
}
