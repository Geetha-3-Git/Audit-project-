package com.audithub;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Gets the Excel bytes: from OneDrive (Microsoft Graph) if configured, otherwise from a local file. */
@Component
public class SourceReader {
    @Value("${onedrive.tenant-id:}") private String tenantId;
    @Value("${onedrive.client-id:}") private String clientId;
    @Value("${onedrive.client-secret:}") private String clientSecret;
    @Value("${onedrive.user:}") private String user;
    @Value("${onedrive.path:AuditHub/faqs.xlsx}") private String path;
    @Value("${local.file:./data/faqs.xlsx}") private String localFile;

    private final HttpClient http = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NEVER).build();
    private final ObjectMapper mapper = new ObjectMapper();

    public boolean oneDriveConfigured() {
        return !tenantId.isBlank() && !clientId.isBlank() && !clientSecret.isBlank() && !user.isBlank();
    }

    public String sourceName() {
        return oneDriveConfigured() ? "OneDrive" : "local file";
    }

    public byte[] read() throws Exception {
        if (oneDriveConfigured()) {
            return fromOneDrive();
        }
        Path p = Path.of(localFile).toAbsolutePath();
        if (!Files.exists(p)) {
            throw new IllegalStateException("Excel file not found: " + p);
        }
        return Files.readAllBytes(p);
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    private String token() throws Exception {
        String body = "client_id=" + enc(clientId) + "&client_secret=" + enc(clientSecret)
                + "&scope=" + enc("https://graph.microsoft.com/.default") + "&grant_type=client_credentials";
        HttpRequest req = HttpRequest.newBuilder(URI.create("https://login.microsoftonline.com/" + tenantId + "/oauth2/v2.0/token"))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(body)).build();
        HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
        JsonNode json = mapper.readTree(res.body());
        if (res.statusCode() != 200) {
            String msg = json.path("error_description").asText("token request failed");
            throw new IllegalStateException("Microsoft login failed: " + msg.split("\r?\n")[0]);
        }
        return json.get("access_token").asText();
    }

    private byte[] fromOneDrive() throws Exception {
        List<String> parts = new ArrayList<>();
        for (String s : path.split("/")) {
            parts.add(enc(s).replace("+", "%20"));
        }
        URI uri = URI.create("https://graph.microsoft.com/v1.0/users/" + user + "/drive/root:/"
                + String.join("/", parts) + ":/content");

        HttpResponse<byte[]> res = http.send(
                HttpRequest.newBuilder(uri).header("Authorization", "Bearer " + token()).GET().build(),
                HttpResponse.BodyHandlers.ofByteArray());

        // Graph redirects to a pre-signed download URL, which must be called WITHOUT the auth header
        if (res.statusCode() / 100 == 3) {
            String location = res.headers().firstValue("Location").orElseThrow();
            res = http.send(HttpRequest.newBuilder(URI.create(location)).GET().build(),
                    HttpResponse.BodyHandlers.ofByteArray());
        }
        if (res.statusCode() != 200) {
            String hint = res.statusCode() == 404 ? " (check ONEDRIVE_USER and ONEDRIVE_PATH)"
                    : (res.statusCode() == 401 || res.statusCode() == 403) ? " (check Files.Read.All permission and admin consent)" : "";
            throw new IllegalStateException("OneDrive download failed: HTTP " + res.statusCode() + hint);
        }
        return res.body();
    }
}
