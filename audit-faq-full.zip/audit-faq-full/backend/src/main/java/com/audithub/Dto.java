package com.audithub;

import java.time.LocalDate;
import java.util.List;

/** JSON shapes. Field names match what the React portal uses. */
public class Dto {
    public record VersionDto(String v, LocalDate date, String by, String note) {}

    public record FaqDto(Long id, String category, String question, String answer, String owner, String status,
                         String reference, LocalDate updated, LocalDate nextReview, List<VersionDto> versions) {}
}
