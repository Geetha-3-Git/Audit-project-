package com.audithub;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class SyncService {
    private static final Logger log = LoggerFactory.getLogger(SyncService.class);

    private final SourceReader source;
    private final FaqStore store;
    private String lastHash = "";
    private volatile String status = "Not synced yet";
    private volatile Instant lastChecked;

    public SyncService(SourceReader source, FaqStore store) {
        this.source = source;
        this.store = store;
    }

    @Scheduled(initialDelay = 1000, fixedDelayString = "${sync.interval-ms:60000}")
    public void scheduled() {
        sync(false);
    }

    public synchronized String sync(boolean force) {
        try {
            byte[] bytes = source.read();
            String hash = Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-256").digest(bytes));
            lastChecked = Instant.now();
            if (!force && hash.equals(lastHash)) {
                status = "No changes in " + source.sourceName() + " (checked)";
                return status;
            }
            ExcelParser.Result parsed = ExcelParser.parse(bytes);
            int n = store.apply(parsed.rows(), parsed.scores());
            lastHash = hash;
            status = "Synced " + n + " FAQs from " + source.sourceName();
        } catch (Exception e) {
            log.error("Sync failed", e);
            status = "Sync failed: " + e.getMessage();
        }
        return status;
    }

    public Map<String, Object> info() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("source", source.sourceName());
        m.put("status", status);
        m.put("lastChecked", lastChecked == null ? null : lastChecked.toString());
        return m;
    }
}
