package com.audithub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class AuditHubApplication {
    public static void main(String[] args) {
        SpringApplication.run(AuditHubApplication.class, args);
    }
}
