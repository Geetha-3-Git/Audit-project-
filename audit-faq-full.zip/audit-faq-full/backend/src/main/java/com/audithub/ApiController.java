package com.audithub;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class ApiController {
    private final FaqStore store;
    private final SyncService sync;

    public ApiController(FaqStore store, SyncService sync) {
        this.store = store;
        this.sync = sync;
    }

    @GetMapping("/faqs")
    public List<Dto.FaqDto> list() {
        return store.list();
    }

    @GetMapping("/faqs/{id}")
    public ResponseEntity<Dto.FaqDto> one(@PathVariable long id) {
        return store.get(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/scores")
    public Map<String, Integer> scores() {
        return store.scores();
    }

    @GetMapping("/sync/status")
    public Map<String, Object> status() {
        return sync.info();
    }

    /** Re-read the Excel file right now. */
    @PostMapping("/sync")
    public Map<String, Object> syncNow() {
        sync.sync(true);
        return sync.info();
    }
}
