# Starts the backend on http://localhost:8080
# Works as-is with the sample Excel file in backend\data\faqs.xlsx
# To read from OneDrive instead, remove the # in front of the 5 lines and fill in your values:
#$env:AZURE_TENANT_ID     = "your-tenant-id"
#$env:AZURE_CLIENT_ID     = "your-client-id"
#$env:AZURE_CLIENT_SECRET = "your-client-secret-VALUE"
#$env:ONEDRIVE_USER       = "you@yourcompany.com"
#$env:ONEDRIVE_PATH       = "AuditHub/faqs.xlsx"

Set-Location "$PSScriptRoot\backend"
mvn spring-boot:run
