# AuditHub - Audit FAQ Portal

```
audit-faq-full
├── backend/              Spring Boot (Java 17+), NO database
│   ├── pom.xml
│   ├── data/faqs.xlsx    sample data (edit this, or use OneDrive)
│   └── src/main/...
├── frontend/             React + Material UI
├── start-backend.ps1
└── start-frontend.ps1
```

## Run (two terminals)
1. `.\start-backend.ps1`   -> wait for "Started AuditHubApplication", then open http://localhost:8080/api/faqs
2. `.\start-frontend.ps1`  -> open http://localhost:5173

Needs: Java 17+, Maven, Node.js 18+.

## How data flows
Excel (local file or OneDrive) -> backend reads it every minute into memory -> /api -> portal.
Edit the Excel file and save: the portal updates by itself. No database needed.

## OneDrive
Open start-backend.ps1, remove the # on the 5 $env lines, fill in your values, run again.
Excel columns: Category, Question, Answer, Owner, Last Updated, Status, Control Reference, Next Review.
Optional second sheet "Compliance": Framework, Score.
