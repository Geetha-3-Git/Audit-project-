import { Box } from '@mui/material';
import { glass } from '../theme';

export default function GlassCard({ sx, children, ...rest }) {
  return (
    <Box sx={{ ...glass, borderRadius: 2, p: 2.5, ...sx }} {...rest}>
      {children}
    </Box>
  );
}
