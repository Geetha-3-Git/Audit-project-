import { Chip } from '@mui/material';

const COLORS = {
  Approved: '#4ADE80', 'Under Review': '#FBBF24', Draft: '#9CA3AF',
  Overdue: '#F87171', 'Due soon': '#FBBF24', 'On track': '#4ADE80',
};

export default function StatusChip({ label }) {
  const c = COLORS[label] || '#9CA3AF';
  return (
    <Chip size="small" label={label}
      sx={{ color: c, bgcolor: `${c}1F`, border: `1px solid ${c}40`, '&::before': { content: '""', width: 6, height: 6, borderRadius: '50%', bgcolor: c, ml: 1 } }} />
  );
}
