import { useEffect, useState } from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField, MenuItem, Box } from '@mui/material';
import { CATEGORIES, STATUSES } from '../data/faqs';
import { useFaqs } from '../data/FaqContext';

const EMPTY = { category: CATEGORIES[0], question: '', answer: '', owner: '', reference: '', status: 'Draft', note: '' };

export default function FaqDialog({ open, onClose, faq }) {
  const { addFaq, updateFaq } = useFaqs();
  const [form, setForm] = useState(EMPTY);
  useEffect(() => { if (open) setForm(faq ? { ...faq, note: '' } : EMPTY); }, [open, faq]);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const valid = form.question.trim() && form.answer.trim() && form.owner.trim();
  const save = () => { faq ? updateFaq(faq.id, form, form.note) : addFaq(form); onClose(); };

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm" PaperProps={{ sx: { border: '1px solid rgba(255,255,255,0.1)' } }}>
      <DialogTitle>{faq ? 'Edit FAQ' : 'Add FAQ'}</DialogTitle>
      <DialogContent>
        <Box sx={{ display: 'grid', gap: 2, pt: 1 }}>
          <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2 }}>
            <TextField select label="Category" value={form.category} onChange={set('category')}>
              {CATEGORIES.map((c) => <MenuItem key={c} value={c}>{c}</MenuItem>)}
            </TextField>
            <TextField select label="Status" value={form.status} onChange={set('status')}>
              {STATUSES.map((s) => <MenuItem key={s} value={s}>{s}</MenuItem>)}
            </TextField>
          </Box>
          <TextField label="Question" value={form.question} onChange={set('question')} multiline minRows={2} />
          <TextField label="Answer" value={form.answer} onChange={set('answer')} multiline minRows={4} />
          <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2 }}>
            <TextField label="Owner" value={form.owner} onChange={set('owner')} />
            <TextField label="Control reference" placeholder="e.g. PCI DSS v4.0 · Req 8.4" value={form.reference} onChange={set('reference')} />
          </Box>
          {faq && <TextField label="Change note (saved in version history)" value={form.note} onChange={set('note')} />}
        </Box>
      </DialogContent>
      <DialogActions sx={{ p: 2.5 }}>
        <Button onClick={onClose} color="inherit">Cancel</Button>
        <Button variant="contained" disabled={!valid} onClick={save}>{faq ? 'Save changes' : 'Create FAQ'}</Button>
      </DialogActions>
    </Dialog>
  );
}
