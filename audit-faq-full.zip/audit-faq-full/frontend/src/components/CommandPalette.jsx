import { useState, useMemo, useEffect } from 'react';
import { Dialog, TextField, List, ListItemButton, ListItemText, Typography, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useFaqs } from '../data/FaqContext';

export default function CommandPalette({ open, onClose }) {
  const { faqs } = useFaqs();
  const nav = useNavigate();
  const [q, setQ] = useState('');
  useEffect(() => { if (open) setQ(''); }, [open]);

  const results = useMemo(() => {
    const s = q.trim().toLowerCase();
    return faqs.filter((f) => !s || `${f.question} ${f.reference} ${f.owner} ${f.category}`.toLowerCase().includes(s)).slice(0, 7);
  }, [q, faqs]);

  const go = (path) => { nav(path); onClose(); };

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm" PaperProps={{ sx: { position: 'absolute', top: '12%', m: 0, border: '1px solid rgba(255,255,255,0.1)' } }}>
      <TextField autoFocus fullWidth placeholder="Search FAQs, control references, owners…" value={q} onChange={(e) => setQ(e.target.value)}
        onKeyDown={(e) => e.key === 'Enter' && results[0] && go(`/faqs/${results[0].id}`)}
        sx={{ '& fieldset': { border: 0, borderBottom: '1px solid rgba(255,255,255,0.08)' }, '& .MuiOutlinedInput-root': { borderRadius: 0 } }} />
      <List dense sx={{ maxHeight: 360, overflow: 'auto' }}>
        {results.map((f) => (
          <ListItemButton key={f.id} onClick={() => go(`/faqs/${f.id}`)}>
            <ListItemText primary={f.question} secondary={`${f.category} · ${f.reference}`} primaryTypographyProps={{ noWrap: true }} />
          </ListItemButton>
        ))}
        {results.length === 0 && <Typography color="text.secondary" sx={{ p: 3, textAlign: 'center' }}>No matches</Typography>}
      </List>
      <Box sx={{ px: 2, py: 1, borderTop: '1px solid rgba(255,255,255,0.08)' }}>
        <Typography variant="caption" color="text.secondary">Enter to open the first result · Esc to close</Typography>
      </Box>
    </Dialog>
  );
}
