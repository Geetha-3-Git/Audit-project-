import { Badge, Button, Box, Drawer, List, ListItemButton, ListItemIcon, ListItemText, Typography, IconButton, AppBar, Toolbar, Avatar, useMediaQuery } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import DashboardIcon from '@mui/icons-material/SpaceDashboardOutlined';
import LibraryIcon from '@mui/icons-material/LibraryBooksOutlined';
import ShieldIcon from '@mui/icons-material/VerifiedUserOutlined';
import AskIcon from '@mui/icons-material/QuestionAnswerOutlined';
import MenuIcon from '@mui/icons-material/Menu';
import { NavLink, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';
import SearchIcon from '@mui/icons-material/Search';
import CommandPalette from './CommandPalette';
import { useFaqs, USE_EXCEL } from '../data/FaqContext';
import { reviewState } from '../data/faqs';
import { ACCENT } from '../theme';

const W = 264;
const NAV = [
  { label: 'Dashboard', to: '/', icon: <DashboardIcon /> },
  { label: 'Ask a Question', to: '/ask', icon: <AskIcon /> },
  { label: 'FAQ Repository', to: '/faqs', icon: <LibraryIcon /> },
];

function SidebarContent({ onNavigate, onSearch }) {
  const { pathname } = useLocation();
  const { faqs, sync, signIn } = useFaqs();
  const overdue = faqs.filter((f) => reviewState(f) === 'Overdue').length;
  const isActive = (to) => (to === '/' ? pathname === '/' : pathname.startsWith(to));
  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', p: 2.5 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 4, px: 1 }}>
        <ShieldIcon sx={{ color: ACCENT, fontSize: 28 }} />
        <Box>
          <Typography variant="h6" sx={{ lineHeight: 1.2 }}>AuditHub</Typography>
          <Typography variant="caption" color="text.secondary">Audit FAQ Portal</Typography>
        </Box>
      </Box>
      <List sx={{ display: 'grid', gap: 0.5 }}>
        {NAV.map((n) => (
          <ListItemButton
            key={n.to}
            component={NavLink}
            to={n.to}
            onClick={onNavigate}
            selected={isActive(n.to)}
            sx={{
              borderRadius: 1.5,
              '&.Mui-selected': {
                background: 'rgba(255,138,61,0.12)',
                color: '#FB923C',
                '& .MuiListItemIcon-root': { color: '#FB923C' },
              },
            }}
          >
            <ListItemIcon sx={{ minWidth: 40 }}>{n.icon}</ListItemIcon>
            <ListItemText primary={n.label} primaryTypographyProps={{ fontWeight: 500 }} />
            {n.to === '/faqs' && overdue > 0 && <Badge badgeContent={overdue} color="error" sx={{ mr: 1.5 }} />}
          </ListItemButton>
        ))}
      </List>
      <ListItemButton onClick={onSearch} sx={{ mt: 2, flexGrow: 0, borderRadius: 1.5, border: '1px solid rgba(255,255,255,0.1)' }}>
        <SearchIcon fontSize="small" sx={{ mr: 1.5, color: 'text.secondary' }} />
        <ListItemText primary="Quick search" primaryTypographyProps={{ variant: 'body2', color: 'text.secondary' }} />
        <Typography variant="caption" color="text.secondary">Ctrl K</Typography>
      </ListItemButton>
      {USE_EXCEL && (
      <>
      <Typography variant="caption" color="text.secondary" sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 2, px: 1 }}>
        <Box sx={{ width: 8, height: 8, flexShrink: 0, borderRadius: '50%', bgcolor: sync.status === 'ok' ? '#4ADE80' : '#FBBF24' }} />
        {sync.label}
      </Typography>
      {sync.status === 'signin' && <Button size="small" variant="contained" onClick={signIn} sx={{ mt: 1, mx: 1 }}>Sign in with Microsoft</Button>}
      </>
      )}
      <Box sx={{ mt: 'auto', display: 'flex', alignItems: 'center', gap: 1.5, px: 1 }}>
        <Avatar sx={{ bgcolor: 'rgba(255,255,255,0.08)', color: 'text.primary', width: 32, height: 32, fontSize: 13 }}>AU</Avatar>
        <Box>
          <Typography variant="body2" fontWeight={600}>Audit Team</Typography>
          <Typography variant="caption" color="text.secondary">Internal Audit</Typography>
        </Box>
      </Box>
    </Box>
  );
}

const paper = {
  width: W,
  background: 'rgba(10,15,24,0.85)',
  backdropFilter: 'blur(12px)',
  WebkitBackdropFilter: 'blur(12px)',
  borderRight: '1px solid rgba(255,255,255,0.08)',
};

export default function Layout({ children }) {
  const theme = useTheme();
  const desktop = useMediaQuery(theme.breakpoints.up('md'));
  const [open, setOpen] = useState(false);
  const [palette, setPalette] = useState(false);
  useEffect(() => {
    const h = (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setPalette(true); } };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      {desktop ? (
        <Drawer variant="permanent" PaperProps={{ sx: paper }} sx={{ width: W, flexShrink: 0 }}>
          <SidebarContent onSearch={() => setPalette(true)} />
        </Drawer>
      ) : (
        <>
          <AppBar position="fixed" elevation={0} color="inherit" sx={{ borderBottom: '1px solid rgba(255,255,255,0.08)', background: 'rgba(10,15,24,0.9)', backdropFilter: 'blur(12px)' }}>
            <Toolbar>
              <IconButton edge="start" onClick={() => setOpen(true)} aria-label="Open navigation"><MenuIcon /></IconButton>
              <Typography variant="h6" sx={{ ml: 1 }}>AuditHub</Typography>
            </Toolbar>
          </AppBar>
          <Drawer open={open} onClose={() => setOpen(false)} PaperProps={{ sx: paper }}>
            <SidebarContent onNavigate={() => setOpen(false)} onSearch={() => { setOpen(false); setPalette(true); }} />
          </Drawer>
        </>
      )}
      <Box component="main" sx={{ flex: 1, minWidth: 0, maxWidth: '100%', overflowX: 'hidden', p: { xs: 2, md: 4 }, pt: { xs: 10, md: 4 } }}>
        {children}
      </Box>
      <CommandPalette open={palette} onClose={() => setPalette(false)} />
    </Box>
  );
}
