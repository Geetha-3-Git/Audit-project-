import { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import readXlsxFile from 'read-excel-file';
import { getToken, downloadFile } from './onedrive';
import { seedFaqs, STATUSES, COMPLIANCE_SCORES, CATEGORIES } from './faqs';

const Ctx = createContext(null);
export const useFaqs = () => useContext(Ctx);

export const DATA_SOURCE = import.meta.env.VITE_DATA_SOURCE || 'sample'; // 'sample' | 'local' | 'onedrive' | 'api'
export const USE_EXCEL = DATA_SOURCE !== 'sample';
const FILE = '/faqs.xlsx';   // put your Excel file in /public
const POLL_MS = DATA_SOURCE === 'onedrive' ? 30000 : DATA_SOURCE === 'api' ? 15000 : 10000; // auto-refresh interval

const p2 = (n) => String(n).padStart(2, '0');
const today = () => new Date().toISOString().slice(0, 10);
const iso = (v) => (!v ? '' : v instanceof Date ? `${v.getFullYear()}-${p2(v.getMonth() + 1)}-${p2(v.getDate())}` : String(v).slice(0, 10));
const addMonths = (d, m) => { const x = new Date(d); x.setMonth(x.getMonth() + m); return x.toISOString().slice(0, 10); };
const bump = (v) => { const [a, b] = v.split('.').map(Number); return `${a}.${b + 1}`; };
const clock = () => new Date().toLocaleTimeString();

const toObjs = (rows) => {
  const [head, ...body] = rows;
  const keys = head.map((h) => String(h || '').trim().toLowerCase());
  return body.map((r) => Object.fromEntries(keys.map((k, i) => [k, r[i]])));
};

const parseFaqs = (rows) =>
  toObjs(rows).filter((r) => r.question).map((r, i) => {
    const updated = iso(r['last updated']) || today();
    const owner = String(r.owner || '').trim();
    const status = STATUSES.find((s) => s.toLowerCase() === String(r.status || '').trim().toLowerCase()) || 'Draft';
    return {
      id: i + 1,
      category: String(r.category || '').trim(),
      question: String(r.question).trim(),
      answer: String(r.answer || '').trim(),
      owner, status, updated,
      reference: String(r['control reference'] || '').trim(),
      nextReview: iso(r['next review']) || addMonths(updated, 12),
      versions: [{ v: '1.0', date: updated, by: owner, note: 'Imported from Excel' }],
    };
  });

const parseScores = (rows) => {
  const out = {};
  toObjs(rows).forEach((r) => { if (r.framework && !isNaN(Number(r.score))) out[String(r.framework).trim()] = Number(r.score); });
  return out;
};

const hash = (buf) => { let h = 0; const b = new Uint8Array(buf); for (let i = 0; i < b.length; i++) h = (h * 31 + b[i]) | 0; return `${b.length}-${h}`; };

export function FaqProvider({ children }) {
  const [faqs, setFaqs] = useState(seedFaqs);
  const [scores, setScores] = useState(COMPLIANCE_SCORES);
  const [sync, setSync] = useState({ status: 'loading', label: '' });
  const lastSig = useRef('');
  const manual = useRef(false);

  const ingest = useCallback(async (blob, label) => {
    const rows = await readXlsxFile(blob);
    const parsed = parseFaqs(rows);
    if (!parsed.length) throw new Error('No FAQ rows found');
    let sc = {};
    try { sc = parseScores(await readXlsxFile(blob, { sheet: 'Compliance' })); } catch { /* optional sheet */ }
    setFaqs(parsed);
    setScores(CATEGORIES.reduce((o, c) => ({ ...o, [c]: sc[c] ?? COMPLIANCE_SCORES[c] }), {}));
    setSync({ status: 'ok', label: `${label} · ${clock()}` });
  }, []);

  const load = useCallback(async () => {
    if (manual.current) return;
    try {
      if (DATA_SOURCE === 'api') {                       // Spring Boot backend
        const [a, b] = await Promise.all([fetch('/api/faqs'), fetch('/api/scores')]);
        if (!a.ok) throw new Error(`Backend error ${a.status}`);
        const txt = await a.text();
        const sc = b.ok ? await b.json() : {};
        if (txt !== lastSig.current) {
          lastSig.current = txt;
          setFaqs(JSON.parse(txt));
          setScores(CATEGORIES.reduce((o, c) => ({ ...o, [c]: sc[c] ?? COMPLIANCE_SCORES[c] }), {}));
        }
        setSync({ status: 'ok', label: `Synced from server · ${clock()}` });
        return;
      }
      let buf;
      if (DATA_SOURCE === 'onedrive') {
        const token = await getToken(false);
        if (!token) { setSync({ status: 'signin', label: 'OneDrive: sign in required' }); return; }
        buf = await downloadFile(token);
      } else {
        const res = await fetch(`${FILE}?t=${Date.now()}`, { cache: 'no-store' });
        if (!res.ok || (res.headers.get('content-type') || '').includes('text/html')) throw new Error('missing');
        buf = await res.arrayBuffer();
      }
      const sig = hash(buf);
      if (sig === lastSig.current) return;           // unchanged
      lastSig.current = sig;
      await ingest(new Blob([buf]), DATA_SOURCE === 'onedrive' ? 'Synced from OneDrive' : 'Synced from faqs.xlsx');
    } catch (e) {
      if (!lastSig.current) setSync({ status: 'warn', label: e.message === 'missing' ? 'Sample data (faqs.xlsx not found)' : e.message === 'Failed to fetch' ? 'Backend not reachable' : e.message });
    }
  }, [ingest]);

  useEffect(() => { if (!USE_EXCEL) return undefined; load(); const t = setInterval(load, POLL_MS); return () => clearInterval(t); }, [load]);

  const signIn = async () => {
    try { await getToken(true); lastSig.current = ''; await load(); }
    catch (e) { setSync({ status: 'warn', label: `Sign-in failed: ${e.message}` }); }
  };

  const importFile = async (file) => {
    if (!file) return;
    try { manual.current = true; await ingest(file, `Imported ${file.name}`); }
    catch (e) { manual.current = false; setSync({ status: 'warn', label: `Import failed: ${e.message}` }); }
  };

  const addFaq = (f) =>
    setFaqs((p) => [{
      category: f.category, question: f.question, answer: f.answer, owner: f.owner, reference: f.reference, status: f.status,
      id: Math.max(0, ...p.map((x) => x.id)) + 1, updated: today(), nextReview: addMonths(today(), 12),
      versions: [{ v: '1.0', date: today(), by: f.owner, note: 'Initial draft created' }],
    }, ...p]);

  const updateFaq = (id, patch, note) =>
    setFaqs((p) => p.map((f) => f.id !== id ? f : {
      ...f, category: patch.category, question: patch.question, answer: patch.answer, owner: patch.owner,
      reference: patch.reference, status: patch.status, updated: today(),
      versions: [{ v: bump(f.versions[0].v), date: today(), by: patch.owner, note: note || 'Content updated' }, ...f.versions],
    }));

  const markReviewed = (id) =>
    setFaqs((p) => p.map((f) => f.id !== id ? f : {
      ...f, nextReview: addMonths(today(), 12), updated: today(),
      versions: [{ v: bump(f.versions[0].v), date: today(), by: f.owner, note: 'Periodic review completed, no changes' }, ...f.versions],
    }));

  return <Ctx.Provider value={{ faqs, scores, sync, signIn, importFile, addFaq, updateFaq, markReviewed }}>{children}</Ctx.Provider>;
}
