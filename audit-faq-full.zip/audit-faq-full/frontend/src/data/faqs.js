export const CATEGORIES = ['PCI DSS', 'Internal Audit', 'BCMS'];

export const COMPLIANCE_SCORES = { 'PCI DSS': 92, 'Internal Audit': 88, BCMS: 81 };

export const faqs = [
  { id: 1, category: 'PCI DSS', question: 'How often must cardholder data environment (CDE) scans be performed?',
    answer: 'External and internal vulnerability scans must run at least quarterly and after any significant change. External scans must be performed by a PCI SSC Approved Scanning Vendor (ASV), and passing reports must be retained as evidence.',
    owner: 'Priya Raman', updated: '2026-10-12' },
  { id: 2, category: 'PCI DSS', question: 'Is stored PAN required to be encrypted?',
    answer: 'Yes. Primary Account Numbers must be rendered unreadable wherever stored, using strong cryptography, truncation, tokenization or hashing. Keys must be managed under documented custody and rotation procedures.',
    owner: 'Priya Raman', updated: '2026-09-28' },
  { id: 3, category: 'PCI DSS', question: 'What evidence is needed for multi-factor authentication?',
    answer: 'Provide MFA configuration screenshots for all CDE access paths, a list of in-scope user groups, and sample authentication logs showing a second factor challenge for both remote and administrative access.',
    owner: 'Arjun Mehta', updated: '2026-10-03' },
  { id: 4, category: 'PCI DSS', question: 'How long must audit logs be retained?',
    answer: 'Retain audit log history for at least 12 months, with a minimum of the most recent three months immediately available for analysis.',
    owner: 'Arjun Mehta', updated: '2026-08-19' },
  { id: 5, category: 'Internal Audit', question: 'What is the standard internal audit cycle?',
    answer: 'High-risk processes are audited annually, medium-risk every 18 months, and low-risk every 24 months. The annual audit plan is approved by the Audit Committee each January.',
    owner: 'Meera Iyer', updated: '2026-10-20' },
  { id: 6, category: 'Internal Audit', question: 'How are audit findings rated?',
    answer: 'Findings are rated Critical, High, Medium or Low based on impact and likelihood. Critical and High findings require a management action plan within 10 business days.',
    owner: 'Meera Iyer', updated: '2026-09-11' },
  { id: 7, category: 'Internal Audit', question: 'Who approves closure of a finding?',
    answer: 'The Internal Audit team validates remediation evidence and the Head of Internal Audit approves closure. Self-attested closure is not accepted for High or Critical findings.',
    owner: 'Karthik Subramanian', updated: '2026-10-25' },
  { id: 8, category: 'Internal Audit', question: 'What documents should auditees prepare before fieldwork?',
    answer: 'Prepare process narratives, policies, organisation charts, prior audit reports, and system access lists. A Provided By Client (PBC) request list is shared at least two weeks before fieldwork.',
    owner: 'Karthik Subramanian', updated: '2026-07-30' },
  { id: 9, category: 'BCMS', question: 'How often is the Business Continuity Plan tested?',
    answer: 'Critical business functions are exercised at least annually through tabletop and technical recovery tests. Results, gaps and corrective actions are reported to the BCMS steering committee.',
    owner: 'Divya Nair', updated: '2026-10-08' },
  { id: 10, category: 'BCMS', question: 'What are the recovery targets for Tier 1 services?',
    answer: 'Tier 1 services have an RTO of 4 hours and an RPO of 15 minutes. Targets are validated in the annual Business Impact Analysis (BIA).',
    owner: 'Divya Nair', updated: '2026-09-02' },
  { id: 11, category: 'BCMS', question: 'When is the Business Impact Analysis refreshed?',
    answer: 'The BIA is reviewed annually and whenever there is a major organisational, technology or supplier change affecting critical processes.',
    owner: 'Rohan Kapoor', updated: '2026-08-14' },
  { id: 12, category: 'BCMS', question: 'How are third-party continuity risks assessed?',
    answer: 'Critical suppliers complete a continuity questionnaire at onboarding and annually thereafter. Suppliers without tested recovery plans are logged in the risk register with an owner and due date.',
    owner: 'Rohan Kapoor', updated: '2026-10-17' },
];

// ---- Enterprise metadata ----
export const STATUSES = ['Approved', 'Under Review', 'Draft'];
const META = {
  1: ['Approved', 'PCI DSS v4.0 · Req 11.3', '2026-12-12'],
  2: ['Approved', 'PCI DSS v4.0 · Req 3.5', '2026-10-15'],
  3: ['Under Review', 'PCI DSS v4.0 · Req 8.4', '2026-11-20'],
  4: ['Approved', 'PCI DSS v4.0 · Req 10.5.1', '2027-02-19'],
  5: ['Approved', 'IA Charter · §4.2', '2027-01-20'],
  6: ['Approved', 'IA Methodology · §6.1', '2026-11-25'],
  7: ['Under Review', 'IA Methodology · §8.3', '2026-12-25'],
  8: ['Draft', 'IA Charter · §5.1', '2026-10-30'],
  9: ['Approved', 'ISO 22301 · Cl. 8.5', '2026-12-08'],
  10: ['Approved', 'ISO 22301 · Cl. 8.2.2', '2026-11-02'],
  11: ['Approved', 'ISO 22301 · Cl. 8.2.3', '2027-02-14'],
  12: ['Under Review', 'ISO 22301 · Cl. 8.4', '2027-01-17'],
};
export const seedFaqs = faqs.map((f) => ({
  ...f,
  status: META[f.id][0],
  reference: META[f.id][1],
  nextReview: META[f.id][2],
  versions: [
    { v: '1.1', date: f.updated, by: f.owner, note: 'Content reviewed and updated' },
    { v: '1.0', date: '2026-03-01', by: f.owner, note: 'Initial publication' },
  ],
}));

export const daysUntil = (iso) => Math.round((new Date(iso) - new Date(new Date().toISOString().slice(0, 10))) / 864e5);
export const reviewState = (f) => {
  const d = daysUntil(f.nextReview);
  return d < 0 ? 'Overdue' : d <= 30 ? 'Due soon' : 'On track';
};
