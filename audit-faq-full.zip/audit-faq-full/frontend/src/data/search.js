// Finds the best FAQ answer for a typed question. Works on whatever data is loaded
// (sample data, OneDrive Excel or the Spring Boot API). No manual steps, no external AI.

const STOP = new Set(('a an the is are was were be been of to in on for and or with what how when who why which do does ' +
  'did can i we you it this that at by from as should must will shall about my our your there their if any').split(' '));

// small synonym map: typed word -> extra words to search for
const SYN = {
  mfa: 'multi factor authentication 2fa', '2fa': 'multi factor authentication mfa', pan: 'primary account number card',
  rto: 'recovery time objective', rpo: 'recovery point objective', bia: 'business impact analysis',
  bcp: 'business continuity plan', log: 'audit log retention', logs: 'audit log retention',
  scan: 'vulnerability scan asv', scans: 'vulnerability scan asv', finding: 'audit finding rating closure',
  findings: 'audit finding rating closure', fieldwork: 'pbc documents prepare', pbc: 'provided by client documents',
  encrypt: 'encryption cryptography', encryption: 'encrypt cryptography', backup: 'recovery continuity',
};

const stem = (w) => (w.length <= 4 ? w : w.replace(/ies$/, 'y').replace(/(ing|ed|es|s)$/, ''));
export const tokens = (t) => (String(t).toLowerCase().match(/[a-z0-9]+/g) || []).filter((w) => !STOP.has(w)).map(stem);
const expand = (q) => String(q).toLowerCase().replace(/[a-z0-9]+/g, (w) => (SYN[w] ? `${w} ${SYN[w]}` : w));
const same = (a, b) => a === b || (Math.min(a.length, b.length) >= 5 && (a.startsWith(b) || b.startsWith(a)));

export function buildIndex(faqs) {
  const docs = faqs.map((f) => ({
    f,
    fields: [[tokens(f.question), 3], [tokens(`${f.reference} ${f.category}`), 2], [tokens(f.answer), 1]],
  }));
  const df = new Map();
  docs.forEach((d) => new Set(d.fields.flatMap(([t]) => t)).forEach((w) => df.set(w, (df.get(w) || 0) + 1)));
  return { docs, df, N: docs.length };
}

export function ask(index, query, limit = 4) {
  const q = [...new Set(tokens(expand(query)))];
  if (!q.length) return [];
  const idf = (w) => Math.log(1 + index.N / (1 + (index.df.get(w) || 0)));
  const total = q.reduce((a, w) => a + idf(w) * 3, 0);
  return index.docs
    .map((d) => {
      let score = 0;
      q.forEach((w) => {
        let best = 0;
        d.fields.forEach(([toks, weight]) => { if (weight > best && toks.some((t) => same(w, t))) best = weight; });
        score += idf(w) * best;
      });
      return { faq: d.f, confidence: Math.min(1, score / total) };
    })
    .filter((r) => r.confidence >= 0.2)
    .sort((a, b) => b.confidence - a.confidence)
    .slice(0, limit);
}
