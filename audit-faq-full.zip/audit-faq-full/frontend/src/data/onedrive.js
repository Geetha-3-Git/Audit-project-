import { PublicClientApplication } from '@azure/msal-browser';

const env = import.meta.env;
const SCOPES = ['Files.Read'];
let app;

async function client() {
  if (!app) {
    app = new PublicClientApplication({
      auth: {
        clientId: env.VITE_MSAL_CLIENT_ID,
        authority: `https://login.microsoftonline.com/${env.VITE_MSAL_TENANT_ID || 'common'}`,
        redirectUri: window.location.origin,
      },
      cache: { cacheLocation: 'localStorage' },
    });
    await app.initialize();
  }
  return app;
}

// interactive=false: silent only (returns null if user must sign in)
export async function getToken(interactive) {
  const msal = await client();
  const account = msal.getAllAccounts()[0];
  if (account) {
    try { return (await msal.acquireTokenSilent({ scopes: SCOPES, account })).accessToken; } catch { /* fall through */ }
  }
  if (!interactive) return null;
  return (await msal.loginPopup({ scopes: SCOPES })).accessToken;
}

function contentUrl() {
  // Option A: file shared from another drive -> set both IDs
  if (env.VITE_ONEDRIVE_DRIVE_ID && env.VITE_ONEDRIVE_ITEM_ID) {
    return `https://graph.microsoft.com/v1.0/drives/${env.VITE_ONEDRIVE_DRIVE_ID}/items/${env.VITE_ONEDRIVE_ITEM_ID}/content`;
  }
  // Option B: file in your own OneDrive, path from root
  const path = (env.VITE_ONEDRIVE_PATH || 'faqs.xlsx').split('/').map(encodeURIComponent).join('/');
  return `https://graph.microsoft.com/v1.0/me/drive/root:/${path}:/content`;
}

export async function downloadFile(token) {
  const res = await fetch(contentUrl(), { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error(res.status === 404 ? 'OneDrive: file not found, check VITE_ONEDRIVE_PATH' : `OneDrive error ${res.status}`);
  return res.arrayBuffer();
}
