import { createTheme } from '@mui/material/styles';

export const ACCENT = '#F97316';        // orange (buttons, active states)
export const ACCENT_TEXT = '#FB923C';   // lighter orange for text on dark
export const ACCENT_SOFT = '#FDBA74';

export const glass = {
  background: 'rgba(255,255,255,0.06)',
  backdropFilter: 'blur(10px)',
  WebkitBackdropFilter: 'blur(10px)',
  border: '1px solid rgba(255,255,255,0.12)',
};

const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: { main: ACCENT, dark: '#EA580C', contrastText: '#FFFFFF' },
    background: { default: '#0A0F18', paper: '#0F1622' },
    text: { primary: '#E8EDF2', secondary: '#8B98A8' },
    divider: 'rgba(255,255,255,0.08)',
  },
  shape: { borderRadius: 8 },
  typography: {
    fontFamily: '"Inter", "Segoe UI", system-ui, sans-serif',
    fontSize: 14,
    h4: { fontWeight: 600, fontSize: '1.5rem', letterSpacing: '-0.01em' },
    h5: { fontWeight: 600, fontSize: '1.25rem' },
    h6: { fontWeight: 600, fontSize: '1rem' },
    button: { textTransform: 'none', fontWeight: 500 },
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          minHeight: '100vh',
          overflowX: 'hidden',
          background: 'linear-gradient(180deg, #0F1826 0%, #0A0F18 60%)',
          backgroundAttachment: 'fixed',
        },
      },
    },
    MuiPaper: { styleOverrides: { root: { backgroundImage: 'none' } } },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          background: 'rgba(255,255,255,0.03)',
          '& fieldset': { borderColor: 'rgba(255,255,255,0.12)' },
          '&:hover fieldset': { borderColor: 'rgba(255,255,255,0.25)' },
          '&.Mui-focused fieldset': { borderColor: ACCENT, borderWidth: 1 },
        },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        root: { borderBottom: '1px solid rgba(255,255,255,0.06)' },
        head: { color: '#8B98A8', fontWeight: 500, fontSize: '0.8rem', background: 'transparent' },
      },
    },
    MuiChip: { styleOverrides: { root: { borderRadius: 6, fontWeight: 500 } } },
  },
});

export default theme;
