import React from 'react';
import { createRoot } from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import { ThemeProvider, CssBaseline } from '@mui/material';
import theme from './theme';
import App from './App';
import { FaqProvider } from './data/FaqContext';

createRoot(document.getElementById('root')).render(
  <ThemeProvider theme={theme}>
    <CssBaseline />
    <HashRouter>
      <FaqProvider><App /></FaqProvider>
    </HashRouter>
  </ThemeProvider>
);
