import { useMemo, useState } from 'react';
import { Box, Typography, TextField, InputAdornment, MenuItem, Table, TableHead, TableRow, TableCell, TableBody, TableContainer, TableSortLabel, TablePagination, Button } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import AddIcon from '@mui/icons-material/Add';
import UploadIcon from '@mui/icons-material/FileUploadOutlined';
import DownloadIcon from '@mui/icons-material/FileDownloadOutlined';
import { useNavigate } from 'react-router-dom';
import GlassCard from '../components/GlassCard';
import StatusChip from '../components/StatusChip';
import FaqDialog from '../components/FaqDialog';
import { useFaqs, USE_EXCEL, DATA_SOURCE } from '../data/FaqContext';
import { CATEGORIES, STATUSES } from '../data/faqs';

const COLS = [
  ['category', 'Category'], ['question', 'Question'], ['status', 'Status'],
  ['nextReview', 'Next Review'], ['owner', 'Owner'], ['updated', 'Last Updated'],
];

export default function Repository() {
  const { faqs, importFile } = useFaqs();
  const nav = useNavigate();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All');
  const [status, setStatus] = useState('All');
  const [sort, setSort] = useState({ by: 'updated', dir: 'desc' });
  const [page, setPage] = useState(0);
  const [per, setPer] = useState(8);
  const [dialog, setDialog] = useState(false);

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = faqs.filter((f) =>
      (category === 'All' || f.category === category) && (status === 'All' || f.status === status) &&
      (!q || `${f.question} ${f.answer} ${f.owner} ${f.reference}`.toLowerCase().includes(q)));
    list.sort((a, b) => String(a[sort.by]).localeCompare(String(b[sort.by])) * (sort.dir === 'asc' ? 1 : -1));
    return list;
  }, [faqs, query, category, status, sort]);

  const exportCsv = () => {
    const head = ['Category', 'Question', 'Status', 'Reference', 'Owner', 'Last Updated', 'Next Review'];
    const esc = (v) => `"${String(v).replace(/"/g, '""')}"`;
    const csv = [head, ...rows.map((f) => [f.category, f.question, f.status, f.reference, f.owner, f.updated, f.nextReview])].map((r) => r.map(esc).join(',')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = 'audit-faqs.csv';
    a.click();
  };

  const reset = (fn) => (e) => { fn(e.target.value); setPage(0); };
  const toggle = (by) => setSort((s) => ({ by, dir: s.by === by && s.dir === 'asc' ? 'desc' : 'asc' }));
  const visible = rows.slice(page * per, page * per + per);

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 2, mb: 3 }}>
        <Box>
          <Typography variant="h4">FAQ Repository</Typography>
          <Typography color="text.secondary">Search and manage audit and compliance FAQs.</Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1.5 }}>
          {USE_EXCEL && DATA_SOURCE !== 'api' && (
          <Button component="label" variant="outlined" color="inherit" startIcon={<UploadIcon />} sx={{ borderColor: 'rgba(255,255,255,0.16)' }}>
            Import Excel
            <input hidden type="file" accept=".xlsx" onChange={(e) => { importFile(e.target.files[0]); e.target.value = ''; }} />
          </Button>
          )}
          <Button variant="outlined" color="inherit" startIcon={<DownloadIcon />} onClick={exportCsv} sx={{ borderColor: 'rgba(255,255,255,0.16)' }}>Export CSV</Button>
          <Button variant="contained" startIcon={<AddIcon />} onClick={() => setDialog(true)}>Add FAQ</Button>
        </Box>
      </Box>

      <GlassCard sx={{ p: 2.5 }}>
        <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', mb: 2.5 }}>
          <TextField placeholder="Search questions, answers, owners, control references" value={query} onChange={reset(setQuery)} sx={{ flex: '1 1 320px' }}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" sx={{ color: 'text.secondary' }} /></InputAdornment> }} />
          <TextField select label="Category" value={category} onChange={reset(setCategory)} sx={{ minWidth: 170 }}>
            <MenuItem value="All">All categories</MenuItem>
            {CATEGORIES.map((c) => <MenuItem key={c} value={c}>{c}</MenuItem>)}
          </TextField>
          <TextField select label="Status" value={status} onChange={reset(setStatus)} sx={{ minWidth: 150 }}>
            <MenuItem value="All">All statuses</MenuItem>
            {STATUSES.map((s) => <MenuItem key={s} value={s}>{s}</MenuItem>)}
          </TextField>
        </Box>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                {COLS.map(([k, label]) => (
                  <TableCell key={k} sortDirection={sort.by === k ? sort.dir : false}>
                    <TableSortLabel active={sort.by === k} direction={sort.by === k ? sort.dir : 'asc'} onClick={() => toggle(k)}>{label}</TableSortLabel>
                  </TableCell>
                ))}
                <TableCell />
              </TableRow>
            </TableHead>
            <TableBody>
              {visible.map((f) => (
                <TableRow key={f.id} hover>
                  <TableCell sx={{ whiteSpace: 'nowrap' }}>{f.category}</TableCell>
                  <TableCell sx={{ minWidth: 280, maxWidth: 420 }}>
                    {f.question}
                    <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>{f.reference}</Typography>
                  </TableCell>
                  <TableCell><StatusChip label={f.status} /></TableCell>
                  <TableCell sx={{ whiteSpace: 'nowrap' }}>{f.nextReview}</TableCell>
                  <TableCell sx={{ whiteSpace: 'nowrap' }}>{f.owner}</TableCell>
                  <TableCell sx={{ whiteSpace: 'nowrap' }}>{f.updated}</TableCell>
                  <TableCell align="right"><Button size="small" variant="outlined" onClick={() => nav(`/faqs/${f.id}`)}>View Details</Button></TableCell>
                </TableRow>
              ))}
              {rows.length === 0 && (
                <TableRow><TableCell colSpan={7} align="center" sx={{ py: 6, color: 'text.secondary' }}>No FAQs match your filters.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination component="div" count={rows.length} page={page} onPageChange={(_, p) => setPage(p)}
          rowsPerPage={per} onRowsPerPageChange={(e) => { setPer(+e.target.value); setPage(0); }} rowsPerPageOptions={[8, 12, 25]} />
      </GlassCard>
      <FaqDialog open={dialog} onClose={() => setDialog(false)} />
    </Box>
  );
}
