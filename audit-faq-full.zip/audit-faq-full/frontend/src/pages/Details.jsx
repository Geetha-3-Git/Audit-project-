import { useState } from 'react';
import { Box, Typography, Button, Chip, Divider, Stepper, Step, StepLabel } from '@mui/material';
import Grid from '@mui/material/Grid2';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import EditIcon from '@mui/icons-material/EditOutlined';
import CopyIcon from '@mui/icons-material/ContentCopy';
import CheckIcon from '@mui/icons-material/TaskAlt';
import { useNavigate, useParams, Link } from 'react-router-dom';
import GlassCard from '../components/GlassCard';
import StatusChip from '../components/StatusChip';
import FaqDialog from '../components/FaqDialog';
import { useFaqs } from '../data/FaqContext';
import { reviewState, daysUntil } from '../data/faqs';
import { ACCENT } from '../theme';

const STEPS = ['Author', 'Reviewer', 'Approver', 'Published'];
const STEP_INDEX = { Draft: 1, 'Under Review': 2, Approved: 4 };

function Field({ label, children }) {
  return (
    <Box>
      <Typography variant="caption" color="text.secondary">{label}</Typography>
      <Box sx={{ fontWeight: 500 }}>{children}</Box>
    </Box>
  );
}

export default function Details() {
  const { id } = useParams();
  const nav = useNavigate();
  const { faqs, markReviewed } = useFaqs();
  const [edit, setEdit] = useState(false);
  const [copied, setCopied] = useState(false);

  const idx = faqs.findIndex((f) => String(f.id) === id);
  const faq = faqs[idx];

  if (!faq) {
    return (
      <Box>
        <Button startIcon={<ArrowBackIcon />} onClick={() => nav('/faqs')} sx={{ mb: 2 }}>Back to repository</Button>
        <GlassCard><Typography variant="h5">FAQ not found</Typography></GlassCard>
      </Box>
    );
  }

  const related = faqs.filter((f) => f.category === faq.category && f.id !== faq.id).slice(0, 3);
  const copy = () => { navigator.clipboard?.writeText(faq.answer); setCopied(true); setTimeout(() => setCopied(false), 1500); };
  const rs = reviewState(faq);

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 1, mb: 2 }}>
        <Button startIcon={<ArrowBackIcon />} onClick={() => nav('/faqs')}>Back to repository</Button>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Button disabled={idx === 0} onClick={() => nav(`/faqs/${faqs[idx - 1].id}`)} color="inherit">Previous</Button>
          <Button disabled={idx === faqs.length - 1} onClick={() => nav(`/faqs/${faqs[idx + 1].id}`)} color="inherit">Next</Button>
        </Box>
      </Box>

      <Grid container spacing={2}>
        <Grid size={{ xs: 12, lg: 8 }}>
          <GlassCard sx={{ p: { xs: 3, md: 4 } }}>
            <Box sx={{ display: 'flex', gap: 1, mb: 2, flexWrap: 'wrap' }}>
              <Chip label={faq.category} variant="outlined" size="small" sx={{ borderColor: 'rgba(255,255,255,0.16)' }} />
              <StatusChip label={faq.status} />
              <Chip label={faq.reference} size="small" sx={{ bgcolor: 'rgba(255,255,255,0.06)' }} />
            </Box>
            <Typography variant="caption" color="text.secondary">Question</Typography>
            <Typography variant="h5" sx={{ mb: 3 }}>{faq.question}</Typography>
            <Divider sx={{ mb: 3 }} />
            <Typography variant="caption" color="text.secondary">Answer</Typography>
            <Typography sx={{ lineHeight: 1.8, maxWidth: '68ch', mt: 0.5 }}>{faq.answer}</Typography>
            <Box sx={{ display: 'flex', gap: 1.5, mt: 3, flexWrap: 'wrap' }}>
              <Button size="small" variant="outlined" startIcon={copied ? <CheckIcon /> : <CopyIcon />} onClick={copy}>{copied ? 'Copied' : 'Copy answer'}</Button>
              <Button size="small" variant="outlined" startIcon={<EditIcon />} onClick={() => setEdit(true)}>Edit</Button>
              <Button size="small" variant="contained" startIcon={<CheckIcon />} onClick={() => markReviewed(faq.id)}>Mark as reviewed</Button>
            </Box>
          </GlassCard>

          <GlassCard sx={{ mt: 2 }}>
            <Typography variant="h6" sx={{ mb: 2 }}>Approval workflow</Typography>
            <Stepper activeStep={STEP_INDEX[faq.status]} alternativeLabel>
              {STEPS.map((s) => <Step key={s}><StepLabel>{s}</StepLabel></Step>)}
            </Stepper>
          </GlassCard>

          <GlassCard sx={{ mt: 2 }}>
            <Typography variant="h6" sx={{ mb: 2 }}>Version history</Typography>
            {faq.versions.map((v, i) => (
              <Box key={v.v} sx={{ display: 'flex', gap: 2, pb: 2, mb: 2, borderBottom: i < faq.versions.length - 1 ? '1px solid rgba(255,255,255,0.08)' : 0 }}>
                <Chip label={`v${v.v}`} size="small" sx={{ bgcolor: i === 0 ? ACCENT : 'rgba(255,255,255,0.08)', color: i === 0 ? '#fff' : 'text.primary' }} />
                <Box>
                  <Typography variant="body2">{v.note}</Typography>
                  <Typography variant="caption" color="text.secondary">{v.by} · {v.date}</Typography>
                </Box>
              </Box>
            ))}
          </GlassCard>
        </Grid>

        <Grid size={{ xs: 12, lg: 4 }}>
          <GlassCard sx={{ display: 'grid', gap: 2.5 }}>
            <Field label="Category">{faq.category}</Field>
            <Field label="Owner">{faq.owner}</Field>
            <Field label="Last Updated">{faq.updated}</Field>
            <Field label="Next review">
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                {faq.nextReview} <StatusChip label={rs} />
              </Box>
              <Typography variant="caption" color="text.secondary">{daysUntil(faq.nextReview) < 0 ? `${-daysUntil(faq.nextReview)} days overdue` : `in ${daysUntil(faq.nextReview)} days`}</Typography>
            </Field>
            <Field label="Control reference">{faq.reference}</Field>
          </GlassCard>

          {related.length > 0 && (
            <GlassCard sx={{ mt: 2 }}>
              <Typography variant="h6" sx={{ mb: 1.5 }}>Related FAQs</Typography>
              {related.map((r) => (
                <Typography key={r.id} component={Link} to={`/faqs/${r.id}`} variant="body2"
                  sx={{ display: 'block', py: 1, color: 'text.primary', textDecoration: 'none', borderTop: '1px solid rgba(255,255,255,0.08)', '&:hover': { color: ACCENT } }}>
                  {r.question}
                </Typography>
              ))}
            </GlassCard>
          )}
        </Grid>
      </Grid>
      <FaqDialog open={edit} onClose={() => setEdit(false)} faq={faq} />
    </Box>
  );
}
