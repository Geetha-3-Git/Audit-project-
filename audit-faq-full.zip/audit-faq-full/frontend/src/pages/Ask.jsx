import { useMemo, useState } from 'react';
import { Box, Typography, TextField, InputAdornment, Chip, Button } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import CopyIcon from '@mui/icons-material/ContentCopy';
import CheckIcon from '@mui/icons-material/TaskAlt';
import { useNavigate } from 'react-router-dom';
import GlassCard from '../components/GlassCard';
import StatusChip from '../components/StatusChip';
import { useFaqs, DATA_SOURCE } from '../data/FaqContext';
import { buildIndex, ask } from '../data/search';
import { ACCENT } from '../theme';

const SOURCE = { sample: 'sample data', local: 'Excel file', onedrive: 'OneDrive Excel', api: 'OneDrive via server' };

export default function Ask() {
  const { faqs, sync } = useFaqs();
  const nav = useNavigate();
  const [q, setQ] = useState('');
  const [copied, setCopied] = useState(false);

  const index = useMemo(() => buildIndex(faqs), [faqs]);          // rebuilt automatically when the data changes
  const results = useMemo(() => (q.trim().length >= 3 ? ask(index, q) : []), [index, q]);
  const [best, ...others] = results;
  const examples = faqs.slice(0, 4).map((f) => f.question);

  const copy = () => { navigator.clipboard?.writeText(best.faq.answer); setCopied(true); setTimeout(() => setCopied(false), 1500); };

  return (
    <Box sx={{ maxWidth: 900, mx: 'auto' }}>
      <Typography variant="h4">Ask a Question</Typography>
      <Typography color="text.secondary" sx={{ mb: 3 }}>
        Type your audit question and get the answer from the FAQ library. Source: {SOURCE[DATA_SOURCE]}{sync.label ? ` · ${sync.label}` : ''} · {faqs.length} FAQs
      </Typography>

      <TextField fullWidth autoFocus value={q} onChange={(e) => setQ(e.target.value)}
        placeholder="e.g. How often must vulnerability scans be performed?"
        InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ color: 'text.secondary' }} /></InputAdornment> }}
        sx={{ mb: 2 }} />

      {q.trim().length < 3 && (
        <Box>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>Try one of these:</Typography>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
            {examples.map((e) => <Chip key={e} label={e} onClick={() => setQ(e)} variant="outlined" sx={{ height: 'auto', py: 0.5, '& .MuiChip-label': { whiteSpace: 'normal' } }} />)}
          </Box>
        </Box>
      )}

      {q.trim().length >= 3 && !best && (
        <GlassCard>
          <Typography variant="h6">No matching FAQ found</Typography>
          <Typography color="text.secondary" sx={{ mt: 0.5 }}>Try different keywords, for example the control name or framework (PCI DSS, BCMS, Internal Audit).</Typography>
        </GlassCard>
      )}

      {best && (
        <GlassCard sx={{ borderTop: `2px solid ${ACCENT}` }}>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 2, alignItems: 'center' }}>
            <Chip size="small" label={`Best match · ${Math.round(best.confidence * 100)}%`} sx={{ bgcolor: ACCENT, color: '#fff' }} />
            <Chip size="small" variant="outlined" label={best.faq.category} sx={{ borderColor: 'rgba(255,255,255,0.16)' }} />
            <StatusChip label={best.faq.status} />
          </Box>
          <Typography variant="caption" color="text.secondary">Matched question</Typography>
          <Typography variant="h6" sx={{ mb: 2 }}>{best.faq.question}</Typography>
          <Typography variant="caption" color="text.secondary">Answer</Typography>
          <Typography sx={{ lineHeight: 1.8, mt: 0.5 }}>{best.faq.answer}</Typography>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 2 }}>
            {best.faq.reference} · Owner: {best.faq.owner} · Updated {best.faq.updated}
          </Typography>
          <Box sx={{ display: 'flex', gap: 1.5, mt: 2 }}>
            <Button size="small" variant="outlined" startIcon={copied ? <CheckIcon /> : <CopyIcon />} onClick={copy}>{copied ? 'Copied' : 'Copy answer'}</Button>
            <Button size="small" variant="outlined" onClick={() => nav(`/faqs/${best.faq.id}`)}>View details</Button>
          </Box>
        </GlassCard>
      )}

      {others.length > 0 && (
        <GlassCard sx={{ mt: 2 }}>
          <Typography variant="h6" sx={{ mb: 1 }}>Related questions</Typography>
          {others.map((r) => (
            <Box key={r.faq.id} onClick={() => nav(`/faqs/${r.faq.id}`)}
              sx={{ display: 'flex', justifyContent: 'space-between', gap: 2, py: 1.25, cursor: 'pointer', borderTop: '1px solid rgba(255,255,255,0.08)', '&:hover': { color: ACCENT } }}>
              <Typography variant="body2">{r.faq.question}</Typography>
              <Typography variant="caption" color="text.secondary" sx={{ whiteSpace: 'nowrap' }}>{Math.round(r.confidence * 100)}%</Typography>
            </Box>
          ))}
        </GlassCard>
      )}
    </Box>
  );
}
