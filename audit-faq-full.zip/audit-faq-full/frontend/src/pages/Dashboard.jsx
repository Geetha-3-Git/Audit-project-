import { Box, Typography, LinearProgress, Table, TableHead, TableRow, TableCell, TableBody } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import GlassCard from '../components/GlassCard';
import StatusChip from '../components/StatusChip';
import { useFaqs } from '../data/FaqContext';
import { CATEGORIES, reviewState, daysUntil, STATUSES } from '../data/faqs';
import { ACCENT, ACCENT_TEXT } from '../theme';


function Bar({ label, value, max, right }) {
  return (
    <Box sx={{ mb: 2, '&:last-child': { mb: 0 } }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.75 }}>
        <Typography variant="body2">{label}</Typography>
        <Typography variant="body2" color="text.secondary">{right ?? value}</Typography>
      </Box>
      <LinearProgress variant="determinate" value={(value / max) * 100}
        sx={{ height: 6, borderRadius: 3, bgcolor: 'rgba(255,255,255,0.08)', '& .MuiLinearProgress-bar': { bgcolor: ACCENT, borderRadius: 3 } }} />
    </Box>
  );
}

export default function Dashboard() {
  const { faqs, scores } = useFaqs();
  const overall = Math.round(CATEGORIES.reduce((a, c) => a + (scores[c] || 0), 0) / CATEGORIES.length);
  const nav = useNavigate();
  const n = (c) => faqs.filter((f) => f.category === c).length;
  const review = (s) => faqs.filter((f) => reviewState(f) === s).length;
  const attention = faqs.filter((f) => reviewState(f) !== 'On track').sort((a, b) => a.nextReview.localeCompare(b.nextReview));

  const stats = [
    { label: 'Total FAQs', value: faqs.length, note: 'Across 3 frameworks' },
    { label: 'PCI DSS FAQs', value: n('PCI DSS'), note: `${Math.round((n('PCI DSS') / faqs.length) * 100)}% of library` },
    { label: 'Internal Audit FAQs', value: n('Internal Audit'), note: `${Math.round((n('Internal Audit') / faqs.length) * 100)}% of library` },
    { label: 'BCMS FAQs', value: n('BCMS'), note: `${Math.round((n('BCMS') / faqs.length) * 100)}% of library` },
    { label: 'Compliance Score', value: `${overall}%`, note: 'Average of 3 frameworks', accent: true },
  ];

  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto' }}>
      <Typography variant="h4">Dashboard</Typography>
      <Typography color="text.secondary" sx={{ mb: 3 }}>Audit knowledge base health at a glance.</Typography>

      <Box sx={{ display: 'grid', gap: 2, mb: 2, gridTemplateColumns: { xs: 'repeat(2, minmax(0, 1fr))', lg: 'repeat(5, minmax(0, 1fr))' }, '& > :last-child': { gridColumn: { xs: 'span 2', lg: 'auto' } } }}>
        {stats.map((s) => (
          <GlassCard key={s.label} sx={{ borderTop: s.accent ? `2px solid ${ACCENT}` : undefined, display: 'flex', flexDirection: 'column', minHeight: 112 }}>
            <Typography variant="body2" color="text.secondary" noWrap>{s.label}</Typography>
            <Typography variant="h4" sx={{ mt: 0.5, color: s.accent ? ACCENT_TEXT : 'text.primary' }}>{s.value}</Typography>
            <Typography variant="caption" color="text.secondary" sx={{ mt: 'auto', pt: 1 }} noWrap>{s.note}</Typography>
          </GlassCard>
        ))}
      </Box>

      <Box sx={{ display: 'grid', gap: 2, mb: 2, alignItems: 'stretch', gridTemplateColumns: { xs: 'minmax(0, 1fr)', lg: 'repeat(3, minmax(0, 1fr))' } }}>
        <GlassCard>
          <Typography variant="h6" sx={{ mb: 2.5 }}>Compliance by framework</Typography>
          {CATEGORIES.map((c) => <Bar key={c} label={c} value={scores[c]} max={100} right={`${scores[c]}%`} />)}
        </GlassCard>

        <GlassCard>
          <Typography variant="h6" sx={{ mb: 2.5 }}>Review health</Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 1.5, mb: 3 }}>
            {['Overdue', 'Due soon', 'On track'].map((s) => (
              <Box key={s} sx={{ p: 1.5, borderRadius: 1.5, border: '1px solid rgba(255,255,255,0.12)' }}>
                <Typography variant="h5">{review(s)}</Typography>
                <Typography variant="caption" color="text.secondary" noWrap>{s}</Typography>
              </Box>
            ))}
          </Box>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>Workflow status</Typography>
          {STATUSES.map((s) => <Bar key={s} label={s} value={faqs.filter((f) => f.status === s).length} max={faqs.length} />)}
        </GlassCard>

        <GlassCard>
          <Typography variant="h6" sx={{ mb: 2.5 }}>FAQs per framework</Typography>
          {CATEGORIES.map((c) => <Bar key={c} label={c} value={n(c)} max={Math.max(...CATEGORIES.map(n))} />)}
        </GlassCard>
      </Box>

      <GlassCard>
        <Typography variant="h6" sx={{ mb: 1 }}>Needs attention</Typography>
        <Box sx={{ overflowX: 'auto' }}>
          <Table size="small">
            <TableHead>
              <TableRow><TableCell>Question</TableCell><TableCell>Reference</TableCell><TableCell>Owner</TableCell><TableCell>Next review</TableCell><TableCell>Review</TableCell></TableRow>
            </TableHead>
            <TableBody>
              {attention.map((f) => (
                <TableRow key={f.id} hover onClick={() => nav(`/faqs/${f.id}`)} sx={{ cursor: 'pointer' }}>
                  <TableCell sx={{ minWidth: 220, maxWidth: 360 }}>{f.question}</TableCell>
                  <TableCell sx={{ whiteSpace: 'nowrap', color: 'text.secondary' }}>{f.reference}</TableCell>
                  <TableCell sx={{ whiteSpace: 'nowrap' }}>{f.owner}</TableCell>
                  <TableCell sx={{ whiteSpace: 'nowrap' }}>{f.nextReview} ({daysUntil(f.nextReview)}d)</TableCell>
                  <TableCell><StatusChip label={reviewState(f)} /></TableCell>
                </TableRow>
              ))}
              {attention.length === 0 && <TableRow><TableCell colSpan={5} align="center" sx={{ py: 4, color: 'text.secondary' }}>All reviews are on track.</TableCell></TableRow>}
            </TableBody>
          </Table>
        </Box>
      </GlassCard>
    </Box>
  );
}
