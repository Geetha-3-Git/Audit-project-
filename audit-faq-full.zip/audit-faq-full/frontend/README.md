# AuditHub – Audit FAQ Portal
React + Material UI (dark, orange accent, soft glass cards).

    npm install
    npm run dev

Routes: `/` Dashboard · `/faqs` FAQ Repository · `/faqs/:id` FAQ Details. Mock data: `src/data/faqs.js`. Press Ctrl+K for quick search.

## Excel as data source (optional, off by default: set USE_EXCEL = true in src/data/FaqContext.jsx)
Edit `public/faqs.xlsx` (sheet **FAQs**: Category, Question, Answer, Owner, Last Updated, Status, Control Reference, Next Review; optional sheet **Compliance**: Framework, Score).
Save the file and the app refreshes itself within ~10 seconds. You can also use **Import Excel** on the FAQ Repository page.
Status: Approved / Under Review / Draft. Category: PCI DSS / Internal Audit / BCMS. Dates: real Excel dates or yyyy-mm-dd.
Note: the browser cannot write back to Excel, so edits made inside the app (Add/Edit) are not saved to the file.

## OneDrive as data source
1. Upload `faqs.xlsx` (same sheets/columns as `public/faqs.xlsx`) to OneDrive, e.g. `AuditHub/faqs.xlsx`.
2. Azure portal → Microsoft Entra ID → App registrations → New registration.
   Platform: **Single-page application**, Redirect URI `http://localhost:5173`.
   API permissions → Microsoft Graph → Delegated → `Files.Read`.
3. Copy `.env.example` to `.env`, set `VITE_DATA_SOURCE=onedrive`, `VITE_MSAL_CLIENT_ID`, `VITE_MSAL_TENANT_ID`, `VITE_ONEDRIVE_PATH`.
4. `npm install`, `npm run dev`, click **Sign in with Microsoft** in the sidebar. The portal re-reads the file every 30 seconds.

## Spring Boot backend (VITE_DATA_SOURCE=api)
Start the backend (see audit-faq-backend), set `VITE_DATA_SOURCE=api` in `.env`, run `npm run dev`.
Vite proxies `/api` to http://localhost:8080. The portal re-reads the API every 15 seconds.
In this mode Excel in OneDrive is the master data; Add/Edit in the UI is not saved to the database.
